default_app_config = 'server.contrib.contenttypes.apps.ContentTypesConfig'
