version = (1, 1, 2)
version_str = '.'.join([str(n) for n in version])
